<?php
// This file was auto-generated from sdk-root/src/data/payment-cryptography-data/2022-02-03/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
