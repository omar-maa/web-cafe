<?php
// This file was auto-generated from sdk-root/src/data/payment-cryptography-data/2022-02-03/paginators-1.json
return [ 'pagination' => [],];
