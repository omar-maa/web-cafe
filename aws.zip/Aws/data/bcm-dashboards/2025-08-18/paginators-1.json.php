<?php
// This file was auto-generated from sdk-root/src/data/bcm-dashboards/2025-08-18/paginators-1.json
return [ 'pagination' => [ 'ListDashboards' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'dashboards', ], ],];
