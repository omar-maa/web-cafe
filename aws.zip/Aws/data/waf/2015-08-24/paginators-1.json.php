<?php
// This file was auto-generated from sdk-root/src/data/waf/2015-08-24/paginators-1.json
return [ 'pagination' => [],];
