<?php
// This file was auto-generated from sdk-root/src/data/aiops/2018-05-10/paginators-1.json
return [ 'pagination' => [ 'ListInvestigationGroups' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'investigationGroups', ], ],];
