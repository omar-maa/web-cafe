<?php
// This file was auto-generated from sdk-root/src/data/support-app/2021-08-20/paginators-1.json
return [ 'pagination' => [ 'ListSlackChannelConfigurations' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', ], 'ListSlackWorkspaceConfigurations' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', ], ],];
