<?php
// This file was auto-generated from sdk-root/src/data/kinesisanalytics/2015-08-14/paginators-1.json
return [ 'pagination' => [],];
