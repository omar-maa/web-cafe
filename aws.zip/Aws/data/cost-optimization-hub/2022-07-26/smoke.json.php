<?php
// This file was auto-generated from sdk-root/src/data/cost-optimization-hub/2022-07-26/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
